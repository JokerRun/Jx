create definer = root@`%` view deliveryreceivedrecordview as
select `ods_prod`.`deliveryreceivedrecord`.`id`           AS `id`,
       `ods_prod`.`deliveryreceivedrecord`.`nr`           AS `nr`,
       `ods_prod`.`deliveryreceivedrecord`.`carTroopId`   AS `carTroopId`,
       `ods_prod`.`deliveryreceivedrecord`.`driverId`     AS `driverId`,
       `ods_prod`.`deliveryreceivedrecord`.`carId`        AS `carId`,
       `ods_prod`.`deliveryreceivedrecord`.`carTrailerId` AS `carTrailerId`,
       `ods_prod`.`deliveryreceivedrecord`.`toId`         AS `toId`,
       `ods_prod`.`deliveryreceivedrecord`.`receivedAt`   AS `receivedAt`,
       `ods_prod`.`deliveryreceivedrecord`.`creatorId`    AS `creatorId`,
       `ods_prod`.`deliveryreceivedrecord`.`receiveType`  AS `receiveType`,
       `ods_prod`.`deliveryreceivedrecord`.`status`       AS `status`,
       `ods_prod`.`deliveryreceivedrecord`.`note`         AS `note`,
       `ods_prod`.`cartroop`.`code`                       AS `cartroopCode`,
       `driver`.`name`                                    AS `driverName`,
       `ods_prod`.`car`.`Nr`                              AS `carNr`,
       `ods_prod`.`cartrailer`.`nr`                       AS `cartrailernr`,
       `ods_prod`.`whouse`.`nr`                           AS `whouseNr`,
       `creator`.`name`                                   AS `creator`
from ((((((`ods_prod`.`deliveryreceivedrecord` left join `ods_prod`.`cartroop` on ((`ods_prod`.`cartroop`.`id` =
                                                                                    `ods_prod`.`deliveryreceivedrecord`.`carTroopId`))) left join `ods_prod`.`user` `driver` on ((`driver`.`id` = `ods_prod`.`deliveryreceivedrecord`.`driverId`))) left join `ods_prod`.`car` on ((`ods_prod`.`car`.`id` = `ods_prod`.`deliveryreceivedrecord`.`carId`))) left join `ods_prod`.`cartrailer` on ((
        `ods_prod`.`cartrailer`.`id` =
        `ods_prod`.`deliveryreceivedrecord`.`carTrailerId`))) left join `ods_prod`.`whouse` on ((`ods_prod`.`whouse`.`id` = `ods_prod`.`deliveryreceivedrecord`.`toId`)))
         left join `ods_prod`.`user` `creator` on ((`creator`.`id` = `ods_prod`.`deliveryreceivedrecord`.`creatorId`)));

