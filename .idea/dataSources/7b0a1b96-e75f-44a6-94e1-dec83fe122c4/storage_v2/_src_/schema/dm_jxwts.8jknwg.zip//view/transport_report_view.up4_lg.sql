create definer = root@`%` view transport_report_view as
select `rep`.`recordNr`                AS `recordnr`,
       `rep`.`transportNr`             AS `transportnr`,
       min(`rep`.`packageNr`)          AS `packagenr`,
       min(`rep`.`checkedAt`)          AS `checkat`,
       min(`rep`.`supplierDesc`)       AS `supplierdesc`,
       min(`rep`.`dockPointCode`)      AS `dockpointcode`,
       min(`rep`.`fromTypeStr`)        AS `fromtypestr`,
       min(`rep`.`fromNr`)             AS `fromnr`,
       min(`rep`.`sendTime`)           AS `sendtime`,
       min(`rep`.`cartrropName`)       AS `cartrropname`,
       min(`rep`.`carTrailerNr`)       AS `cartrailernr`,
       min(`rep`.`receivedAt`)         AS `receivedat`,
       min(`rep`.`carNr`)              AS `carnr`,
       min(`rep`.`carTypeNr`)          AS `cartypenr`,
       min(`rep`.`toWhouseNr`)         AS `towhousenr`,
       min(`rep`.`driverName`)         AS `drivername`,
       min(`rep`.`driverPhone`)        AS `driverphone`,
       sum(`rep`.`trayCount`)          AS `traycount`,
       sum(`rep`.`singlePackageCount`) AS `singlepackagecount`,
       sum(`rep`.`valumem`)            AS `valumem`
from `dm_jxwts`.`stage_transport_report` `rep`
group by `rep`.`recordNr`, `rep`.`transportNr`;

