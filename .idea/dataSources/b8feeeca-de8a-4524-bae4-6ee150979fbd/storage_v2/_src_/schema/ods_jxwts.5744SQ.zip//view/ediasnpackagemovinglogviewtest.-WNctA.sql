create view ediasnpackagemovinglogviewtest as
select `ods_jxwts`.`ediasnpackagemovinglog`.`id`         AS `id`,
       `ods_jxwts`.`ediasnpackagemovinglog`.`packageId`  AS `packageId`,
       `ods_jxwts`.`ediasnpackagemovinglog`.`whouseId`   AS `whouseId`,
       `ods_jxwts`.`ediasnpackagemovinglog`.`carId`      AS `carId`,
       `ods_jxwts`.`ediasnpackagemovinglog`.`driverId`   AS `driverId`,
       `ods_jxwts`.`ediasnpackagemovinglog`.`creatorId`  AS `creatorId`,
       `ods_jxwts`.`ediasnpackagemovinglog`.`createdAt`  AS `createdAt`,
       `ods_jxwts`.`ediasnpackagemovinglog`.`actionType` AS `actionType`,
       `ods_jxwts`.`ediasnpackagemovinglog`.`relationId` AS `relationId`,
       `ods_jxwts`.`ediasnpackage`.`nr`                  AS `ediAsnPackageNr`,
       `ods_jxwts`.`ediasnpackage`.`ediAsnTransportId`   AS `ediAsnTransportId`,
       `ods_jxwts`.`ediasnpackage`.`ediDeliveryNodeId`   AS `ediDeliveryNodeId`,
       `ods_jxwts`.`ediasnpackage`.`quantityperpack`     AS `quantityperpack`,
       `ods_jxwts`.`ediasnpackage`.`packagetype`         AS `packagetype`,
       `ods_jxwts`.`ediasnpackage`.`quantitypack`        AS `quantitypack`,
       `ods_jxwts`.`ediasnpackage`.`partId`              AS `partId`,
       `ods_jxwts`.`ediasnpackage`.`orderno`             AS `orderno`,
       `ods_jxwts`.`ediasnpackage`.`supplierId`          AS `supplierId`,
       `ods_jxwts`.`ediasnpackage`.`milkDate`            AS `milkDate`,
       `ods_jxwts`.`ediasnpackage`.`parentPackageId`     AS `parentPackageId`,
       `ods_jxwts`.`ediasnpackage`.`state`               AS `state`,
       `ods_jxwts`.`ediasnpackage`.`dataSourceType`      AS `dataSourceType`,
       `ods_jxwts`.`ediasnpackage`.`dockPointId`         AS `dockPointId`,
       `ods_jxwts`.`ediasnpackage`.`delivDate`           AS `delivDate`,
       `ods_jxwts`.`ediasndeliverynode`.`delnotenumber`  AS `delnotenumber`,
       `ods_jxwts`.`dockpoint`.`code`                    AS `dockPointCode`,
       `ods_jxwts`.`part`.`Nr`                           AS `partNr`,
       `ods_jxwts`.`part`.`supplierCode`                 AS `supplierCode`,
       `ods_jxwts`.`whouse`.`nr`                         AS `whouseNr`,
       `ods_jxwts`.`whouse`.`name`                       AS `whouseName`,
       `ods_jxwts`.`car`.`Nr`                            AS `carNr`,
       `ods_jxwts`.`user`.`phone`                        AS `driverPhone`,
       `ods_jxwts`.`user`.`name`                         AS `driverName`,
       `creator`.`name`                                  AS `creatorName`,
       `creator`.`phone`                                 AS `creatorPhone`,
       `ods_jxwts`.`ediasntransport`.`transportnumber`   AS `transportNr`,
       `ods_jxwts`.`ediasntransport`.`arrivaldate`       AS `arrivalDate`
from (((((((((`ods_jxwts`.`ediasnpackagemovinglog` left join `ods_jxwts`.`whouse` on ((
        `ods_jxwts`.`ediasnpackagemovinglog`.`whouseId` =
        `ods_jxwts`.`whouse`.`id`))) left join `ods_jxwts`.`car` on ((`ods_jxwts`.`ediasnpackagemovinglog`.`carId` = `ods_jxwts`.`car`.`id`))) left join `ods_jxwts`.`user` on ((
        `ods_jxwts`.`ediasnpackagemovinglog`.`driverId` =
        `ods_jxwts`.`user`.`id`))) left join `ods_jxwts`.`user` `creator` on ((`ods_jxwts`.`ediasnpackagemovinglog`.`creatorId` = `creator`.`id`))) left join `ods_jxwts`.`ediasnpackage` on ((
        `ods_jxwts`.`ediasnpackagemovinglog`.`packageId` =
        `ods_jxwts`.`ediasnpackage`.`id`))) left join `ods_jxwts`.`ediasntransport` on ((
        `ods_jxwts`.`ediasnpackage`.`ediAsnTransportId` =
        `ods_jxwts`.`ediasntransport`.`id`))) left join `ods_jxwts`.`ediasndeliverynode` on ((
        `ods_jxwts`.`ediasnpackage`.`ediDeliveryNodeId` =
        `ods_jxwts`.`ediasndeliverynode`.`id`))) left join `ods_jxwts`.`dockpoint` on ((
        `ods_jxwts`.`ediasnpackage`.`dockPointId` = `ods_jxwts`.`dockpoint`.`id`)))
         left join `ods_jxwts`.`part` on ((`ods_jxwts`.`ediasnpackage`.`partId` = `ods_jxwts`.`part`.`id`)));

