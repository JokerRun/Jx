create definer = root@`%` view edi_asn_package_moving_log_view as
select `ods_jxwts`.`ediasnpackagemovinglog`.`id`         AS `id`,
       `ods_jxwts`.`whouse`.`nr`                         AS `whouse_nr`,
       `ods_jxwts`.`ediasnpackagemovinglog`.`actionType` AS `action_type`,
       `creator`.`name`                                  AS `creator_name`,
       `ods_jxwts`.`car`.`Nr`                            AS `car_nr`,
       `ods_jxwts`.`user`.`name`                         AS `driver_name`,
       `ods_jxwts`.`user`.`phone`                        AS `driver_phone`,
       `ods_jxwts`.`ediasntransport`.`transportnumber`   AS `transport_nr`,
       `ods_jxwts`.`ediasndeliverynode`.`delnotenumber`  AS `delnote_number`,
       `ods_jxwts`.`ediasnpackage`.`nr`                  AS `edi_asn_package_nr`,
       `ods_jxwts`.`part`.`Nr`                           AS `part_nr`,
       `ods_jxwts`.`ediasnpackage`.`quantityperpack`     AS `quantity_perpack`,
       `ods_jxwts`.`ediasnpackage`.`supplierId`          AS `supplier_id`,
       `ods_jxwts`.`part`.`supplierCode`                 AS `supplier_code`,
       `ods_jxwts`.`dockpoint`.`code`                    AS `dockpoint_code`,
       `ods_jxwts`.`ediasntransport`.`arrivaldate`       AS `arrival_date`,
       `ods_jxwts`.`ediasnpackagemovinglog`.`createdAt`  AS `created_at`
from (((((((((`ods_jxwts`.`ediasnpackagemovinglog` left join `ods_jxwts`.`whouse` on ((
        `ods_jxwts`.`ediasnpackagemovinglog`.`whouseId` =
        `ods_jxwts`.`whouse`.`id`))) left join `ods_jxwts`.`car` on ((`ods_jxwts`.`ediasnpackagemovinglog`.`carId` = `ods_jxwts`.`car`.`id`))) left join `ods_jxwts`.`user` on ((
        `ods_jxwts`.`ediasnpackagemovinglog`.`driverId` =
        `ods_jxwts`.`user`.`id`))) left join `ods_jxwts`.`user` `creator` on ((`ods_jxwts`.`ediasnpackagemovinglog`.`creatorId` = `creator`.`id`))) left join `ods_jxwts`.`ediasnpackage` on ((
        `ods_jxwts`.`ediasnpackagemovinglog`.`packageId` =
        `ods_jxwts`.`ediasnpackage`.`id`))) left join `ods_jxwts`.`ediasntransport` on ((
        `ods_jxwts`.`ediasnpackage`.`ediAsnTransportId` =
        `ods_jxwts`.`ediasntransport`.`id`))) left join `ods_jxwts`.`ediasndeliverynode` on ((
        `ods_jxwts`.`ediasnpackage`.`ediDeliveryNodeId` =
        `ods_jxwts`.`ediasndeliverynode`.`id`))) left join `ods_jxwts`.`dockpoint` on ((
        `ods_jxwts`.`ediasnpackage`.`dockPointId` = `ods_jxwts`.`dockpoint`.`id`)))
         left join `ods_jxwts`.`part` on ((`ods_jxwts`.`ediasnpackage`.`partId` = `ods_jxwts`.`part`.`id`)));

