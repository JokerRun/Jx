create definer = root@`%` view package_account_report_view as
select `ods_jxwts`.`ediasntransport`.`transportnumber`  AS `asn_transport_nr`,
       `ods_jxwts`.`ediasndeliverynode`.`delnotenumber` AS `asn_delivery_node_nr`,
       `ods_jxwts`.`ediasnpackage`.`nr`                 AS `asn_package_nr`,
       `ods_jxwts`.`ediasnpackage`.`state`              AS `state`,
       `ods_jxwts`.`ediasntransport`.`isVerify`         AS `is_verify`,
       `ods_jxwts`.`ediasnpackage`.`isSAPReceived`      AS `is_sap_received`,
       `ods_jxwts`.`part`.`Nr`                          AS `part_nr`,
       `ods_jxwts`.`ediasnpackage`.`totalQty`           AS `total_qty`,
       `ods_jxwts`.`ediasnpackage`.`packagetype`        AS `package_type`,
       `ods_jxwts`.`part`.`kltContent`                  AS `klt_content`,
       `ods_jxwts`.`part`.`kltLength`                   AS `klt_length`,
       `ods_jxwts`.`part`.`kltWidth`                    AS `klt_width`,
       `ods_jxwts`.`part`.`kltHeight`                   AS `klt_height`,
       `ods_jxwts`.`part`.`luContent`                   AS `lu_content`,
       `ods_jxwts`.`part`.`luLength`                    AS `lu_length`,
       `ods_jxwts`.`part`.`luWidth`                     AS `lu_width`,
       `ods_jxwts`.`part`.`luHeight`                    AS `lu_height`,
       `ods_jxwts`.`part`.`grossWeight`                 AS `gross_weight`,
       `ods_jxwts`.`part`.`tareWeight`                  AS `tare_weight`,
       `ods_jxwts`.`supplier`.`description`             AS `supplier_desc`,
       `ods_jxwts`.`supplier`.`code`                    AS `supplier_code`,
       `ods_jxwts`.`ediasntransport`.`arrivaldate`      AS `asn_arrival_date`,
       `ods_jxwts`.`ediasnpackage`.`milkDate`           AS `milk_date`,
       `ods_jxwts`.`ediasnpackage`.`receivedAt`         AS `received_at`,
       `ods_jxwts`.`ediasnpackage`.`sapReceivedAt`      AS `sap_received_at`,
       `ods_jxwts`.`ediasnpackage`.`receiverId`         AS `receiver_id`,
       `ods_jxwts`.`whouse`.`nr`                        AS `whouse_nr`,
       `ods_jxwts`.`dockpoint`.`code`                   AS `dockpoint_code`,
       `ods_jxwts`.`ediasnpackage`.`createdAt`          AS `asn_created_at`,
       `ods_jxwts`.`ediasnpackage`.`createdAt`          AS `created_at`
from ((((((`ods_jxwts`.`ediasnpackage` left join `ods_jxwts`.`part` on ((`ods_jxwts`.`ediasnpackage`.`partId` = `ods_jxwts`.`part`.`id`))) left join `ods_jxwts`.`ediasndeliverynode` on ((
        `ods_jxwts`.`ediasnpackage`.`ediDeliveryNodeId` =
        `ods_jxwts`.`ediasndeliverynode`.`id`))) left join `ods_jxwts`.`ediasntransport` on ((
        `ods_jxwts`.`ediasnpackage`.`ediAsnTransportId` =
        `ods_jxwts`.`ediasntransport`.`id`))) left join `ods_jxwts`.`supplier` on ((
        `ods_jxwts`.`ediasnpackage`.`supplierId` = `ods_jxwts`.`supplier`.`id`))) left join `ods_jxwts`.`whouse` on ((
        `ods_jxwts`.`ediasnpackage`.`currentWhouseId` = `ods_jxwts`.`whouse`.`id`)))
         left join `ods_jxwts`.`dockpoint`
                   on ((`ods_jxwts`.`ediasnpackage`.`currentDockPointId` = `ods_jxwts`.`dockpoint`.`id`)));

