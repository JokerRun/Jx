create definer = root@`%` view stage_transport_report_view as
select `ods_prod`.`deliveryreceivededipackagerelation`.`id`                     AS `id`,
       `ods_prod`.`deliveryreceivedrecord`.`nr`                                 AS `recordnr`,
       `ods_prod`.`ediasntransport`.`transportnumber`                           AS `transportnr`,
       `ods_prod`.`ediasnpackage`.`nr`                                          AS `packagenr`,
       `ods_prod`.`ediasnpackage`.`checkedAt`                                   AS `checkedat`,
       `ods_prod`.`supplier`.`description`                                      AS `supplierdesc`,
       `ods_prod`.`dockpoint`.`code`                                            AS `dockpointcode`,
       (case `ods_prod`.`deliveryreceivededipackagerelation`.`fromType`
            when 1 then '供应商'
            when 2 then '自有仓库'
            else '' end)                                                        AS `fromtypestr`,
       (case `ods_prod`.`deliveryreceivededipackagerelation`.`fromType`
            when 1 then `from_house`.`nr`
            when 2 then `ods_prod`.`supplier`.`code`
            else '' end)                                                        AS `fromnr`,
       `ods_prod`.`deliveryreceivededipackagerelation`.`sendTime`               AS `sendtime`,
       `ods_prod`.`cartroop`.`name`                                             AS `cartrropname`,
       `ods_prod`.`cartrailer`.`nr`                                             AS `cartrailernr`,
       `ods_prod`.`deliveryreceivedrecord`.`receivedAt`                         AS `receivedat`,
       `ods_prod`.`car`.`Nr`                                                    AS `carnr`,
       `ods_prod`.`cartype`.`nr`                                                AS `cartypenr`,
       `to_house`.`nr`                                                          AS `towhousenr`,
       `ods_prod`.`user`.`name`                                                 AS `drivername`,
       `ods_prod`.`user`.`phone`                                                AS `driverphone`,
       (case `ods_prod`.`ediasnpackage`.`packagetype` when 1 then 1 else 0 end) AS `traycount`,
       (case `ods_prod`.`ediasnpackage`.`packagetype` when 3 then 1 else 0 end) AS `singlepackagecount`,
       round((case
                  when (`ods_prod`.`ediasnpackage`.`packagetype` = 1) then (
                          ((((`ods_prod`.`part`.`luLength` / 1000) * `ods_prod`.`part`.`luWidth`) / 1000) *
                           `ods_prod`.`part`.`luHeight`) / 1000)
                  when (`ods_prod`.`ediasnpackage`.`packagetype` = 3) then (
                          ((((`ods_prod`.`part`.`kltLength` / 1000) * `ods_prod`.`part`.`kltWidth`) / 1000) *
                           `ods_prod`.`part`.`kltHeight`) / 1000)
                  else 0.0 end), 4)                                             AS `valumem`
from ((((((((((((((`ods_prod`.`deliveryreceivededipackagerelation` left join `ods_prod`.`whouse` `from_house` on ((
        `ods_prod`.`deliveryreceivededipackagerelation`.`fromId` =
        `from_house`.`id`))) left join `ods_prod`.`ediasnpackage` on ((
        `ods_prod`.`deliveryreceivededipackagerelation`.`ediAsnPackageId` =
        `ods_prod`.`ediasnpackage`.`id`))) left join `ods_prod`.`ediasntransport` on ((
        `ods_prod`.`ediasnpackage`.`ediAsnTransportId` =
        `ods_prod`.`ediasntransport`.`id`))) left join `ods_prod`.`part` on ((`ods_prod`.`ediasnpackage`.`partId` = `ods_prod`.`part`.`id`))) left join `ods_prod`.`supplier` on ((`ods_prod`.`ediasnpackage`.`supplierId` = `ods_prod`.`supplier`.`id`))) left join `ods_prod`.`dockpoint` on ((
        `ods_prod`.`ediasnpackage`.`dockPointId` =
        `ods_prod`.`dockpoint`.`id`))) left join `ods_prod`.`deliveryreceivedrecord` on ((
        `ods_prod`.`deliveryreceivededipackagerelation`.`deliveryReceivedRecordId` =
        `ods_prod`.`deliveryreceivedrecord`.`id`))) left join `ods_prod`.`user` on ((
        `ods_prod`.`deliveryreceivedrecord`.`driverId` =
        `ods_prod`.`user`.`id`))) left join `ods_prod`.`user` `creator` on ((`ods_prod`.`deliveryreceivedrecord`.`creatorId` = `creator`.`id`))) left join `ods_prod`.`whouse` `to_house` on ((`ods_prod`.`deliveryreceivedrecord`.`toId` = `to_house`.`id`))) left join `ods_prod`.`car` on ((`ods_prod`.`deliveryreceivedrecord`.`carId` = `ods_prod`.`car`.`id`))) left join `ods_prod`.`cartype` on ((`ods_prod`.`car`.`carTypeId` = `ods_prod`.`cartype`.`id`))) left join `ods_prod`.`cartrailer` on ((
        `ods_prod`.`cartrailer`.`id` = `ods_prod`.`deliveryreceivedrecord`.`carTrailerId`)))
         left join `ods_prod`.`cartroop`
                   on ((`ods_prod`.`cartroop`.`id` = `ods_prod`.`deliveryreceivedrecord`.`carTroopId`)));

