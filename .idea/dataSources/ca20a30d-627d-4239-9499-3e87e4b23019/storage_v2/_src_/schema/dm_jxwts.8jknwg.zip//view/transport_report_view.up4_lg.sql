create definer = root@`%` view transport_report_view as
select `rep`.`record_nr`                 AS `record_nr`,
       `rep`.`transport_nr`              AS `transport_nr`,
       min(`rep`.`package_nr`)           AS `package_nr`,
       min(`rep`.`checked_at`)           AS `checked_at`,
       min(`rep`.`supplier_desc`)        AS `supplier_desc`,
       min(`rep`.`dockpoint_code`)       AS `dockpoint_code`,
       min(`rep`.`from_type_str`)        AS `from_type_str`,
       min(`rep`.`from_nr`)              AS `from_nr`,
       min(`rep`.`send_time`)            AS `send_time`,
       min(`rep`.`car_trrop_name`)       AS `car_trrop_name`,
       min(`rep`.`car_trailer_nr`)       AS `car_trailer_nr`,
       min(`rep`.`received_at`)          AS `received_at`,
       min(`rep`.`car_nr`)               AS `car_nr`,
       min(`rep`.`car_type_nr`)          AS `car_type_nr`,
       min(`rep`.`to_whousenr`)          AS `to_whousenr`,
       min(`rep`.`driver_name`)          AS `driver_name`,
       min(`rep`.`driver_phone`)         AS `driver_phone`,
       sum(`rep`.`tray_count`)           AS `tray_count`,
       sum(`rep`.`single_package_count`) AS `single_package_count`,
       sum(`rep`.`valumem`)              AS `valumem`
from `dm_jxwts`.`stage_transport_report` `rep`
group by `rep`.`record_nr`, `rep`.`transport_nr`;

