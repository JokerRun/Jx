create definer = root@`%` view delivery_received_record_view as
select `ods_prod`.`deliveryreceivedrecord`.`id`           AS `id`,
       `ods_prod`.`deliveryreceivedrecord`.`nr`           AS `nr`,
       `ods_prod`.`deliveryreceivedrecord`.`carTroopId`   AS `car_troop_id`,
       `ods_prod`.`deliveryreceivedrecord`.`driverId`     AS `driver_id`,
       `ods_prod`.`deliveryreceivedrecord`.`carId`        AS `car_id`,
       `ods_prod`.`deliveryreceivedrecord`.`carTrailerId` AS `car_trailer_id`,
       `ods_prod`.`deliveryreceivedrecord`.`toId`         AS `to_id`,
       `ods_prod`.`deliveryreceivedrecord`.`receivedAt`   AS `received_at`,
       `ods_prod`.`deliveryreceivedrecord`.`creatorId`    AS `creator_id`,
       `ods_prod`.`deliveryreceivedrecord`.`receiveType`  AS `receive_type`,
       `ods_prod`.`deliveryreceivedrecord`.`status`       AS `status`,
       `ods_prod`.`deliveryreceivedrecord`.`note`         AS `note`,
       `ods_prod`.`cartroop`.`code`                       AS `car_troop_code`,
       `driver`.`name`                                    AS `driver_name`,
       `ods_prod`.`car`.`Nr`                              AS `car_nr`,
       `ods_prod`.`cartrailer`.`nr`                       AS `car_trailer_nr`,
       `ods_prod`.`whouse`.`nr`                           AS `whouse_nr`,
       `creator`.`name`                                   AS `creator`
from ((((((`ods_prod`.`deliveryreceivedrecord` left join `ods_prod`.`cartroop` on ((`ods_prod`.`cartroop`.`id` =
                                                                                    `ods_prod`.`deliveryreceivedrecord`.`carTroopId`))) left join `ods_prod`.`user` `driver` on ((`driver`.`id` = `ods_prod`.`deliveryreceivedrecord`.`driverId`))) left join `ods_prod`.`car` on ((`ods_prod`.`car`.`id` = `ods_prod`.`deliveryreceivedrecord`.`carId`))) left join `ods_prod`.`cartrailer` on ((
        `ods_prod`.`cartrailer`.`id` =
        `ods_prod`.`deliveryreceivedrecord`.`carTrailerId`))) left join `ods_prod`.`whouse` on ((`ods_prod`.`whouse`.`id` = `ods_prod`.`deliveryreceivedrecord`.`toId`)))
         left join `ods_prod`.`user` `creator` on ((`creator`.`id` = `ods_prod`.`deliveryreceivedrecord`.`creatorId`)));

