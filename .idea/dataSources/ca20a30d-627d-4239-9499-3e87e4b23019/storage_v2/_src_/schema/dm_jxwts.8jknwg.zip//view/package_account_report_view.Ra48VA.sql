create definer = root@`%` view package_account_report_view as
select `ods_prod`.`ediasnpackage`.`id`                                                         AS `id`,
       `ods_prod`.`ediasnpackage`.`nr`                                                         AS `asn_package_nr`,
       `ods_prod`.`ediasntransport`.`transportnumber`                                          AS `asn_transport_nr`,
       `ods_prod`.`ediasndeliverynode`.`delnotenumber`                                         AS `asn_delivery_node_nr`,
       (case
            when (`ods_prod`.`ediasnpackage`.`state` = 50) then '创建'
            when (`ods_prod`.`ediasnpackage`.`state` = 90) then '已配载'
            when (`ods_prod`.`ediasnpackage`.`state` = 100) then '已备货'
            when (`ods_prod`.`ediasnpackage`.`state` = 400) then '已验收'
            when (`ods_prod`.`ediasnpackage`.`state` = 401) then '部分验收'
            when (`ods_prod`.`ediasnpackage`.`state` = 500) then '送货中'
            when (`ods_prod`.`ediasnpackage`.`state` = 501) then '部分送货途中'
            when (`ods_prod`.`ediasnpackage`.`state` = 600) then '已送达'
            when (`ods_prod`.`ediasnpackage`.`state` = 601) then '部分送达'
            when (`ods_prod`.`ediasnpackage`.`state` = 700) then '已接收'
            when (`ods_prod`.`ediasnpackage`.`state` = 701) then '部分接收'
            when (`ods_prod`.`ediasnpackage`.`state` = 800) then '已交付'
            when (`ods_prod`.`ediasnpackage`.`state` = 801) then '部分交付'
            else '未知状态' end)                                                                   AS `state`,
       (case `ods_prod`.`ediasntransport`.`isVerify` when 'true' then '是' else '否' end)        AS `is_verify`,
       (case `ods_prod`.`ediasnpackage`.`isSAPReceived` when 'true' then '已交付' else '未交付' end) AS `is_sap_received`,
       `ods_prod`.`part`.`Nr`                                                                  AS `part_nr`,
       `ods_prod`.`ediasnpackage`.`totalQty`                                                   AS `total_qty`,
       (case
            when (`ods_prod`.`ediasnpackage`.`packagetype` = 1) then '托'
            when (`ods_prod`.`ediasnpackage`.`packagetype` = 2) then '混合'
            when (`ods_prod`.`ediasnpackage`.`packagetype` = 3) then '箱'
            when (`ods_prod`.`ediasnpackage`.`packagetype` = 999) then '未知'
            else '未知' end)                                                                     AS `package_type`,
       round(((case
                   when (`ods_prod`.`ediasnpackage`.`packagetype` = 1) then (
                           (`ods_prod`.`part`.`luLength` * `ods_prod`.`part`.`luWidth`) * `ods_prod`.`part`.`luHeight`)
                   when (`ods_prod`.`ediasnpackage`.`packagetype` = 3) then (
                           (`ods_prod`.`part`.`kltLength` * `ods_prod`.`part`.`kltWidth`) *
                           `ods_prod`.`part`.`kltHeight`)
                   else 0.0 end) / 1000000000), 1)                                             AS `valumem`,
       round((case
                  when (`ods_prod`.`ediasnpackage`.`packagetype` = 1) then `ods_prod`.`part`.`grossWeight`
                  when (`ods_prod`.`ediasnpackage`.`packagetype` = 3) then `ods_prod`.`part`.`tareWeight`
                  else 0.0 end), 1)                                                            AS `weightt`,
       `ods_prod`.`part`.`grossWeight`                                                         AS `gross_weight`,
       `ods_prod`.`part`.`tareWeight`                                                          AS `tare_weight`,
       `ods_prod`.`supplier`.`description`                                                     AS `supplier_desc`,
       `ods_prod`.`supplier`.`code`                                                            AS `supplier_code`,
       `ods_prod`.`ediasntransport`.`arrivaldate`                                              AS `asn_arrival_date`,
       `ods_prod`.`ediasnpackage`.`milkDate`                                                   AS `milk_date`,
       `ods_prod`.`ediasnpackage`.`receivedAt`                                                 AS `received_at`,
       `ods_prod`.`ediasnpackage`.`sapReceivedAt`                                              AS `sap_received_at`,
       `ods_prod`.`ediasnpackage`.`receiverId`                                                 AS `receiver_id`,
       `ods_prod`.`user`.`name`                                                                AS `receiver_name`,
       `ods_prod`.`user`.`phone`                                                               AS `receiver_phone`,
       `ods_prod`.`whouse`.`nr`                                                                AS `whouse_nr`,
       `ods_prod`.`dockpoint`.`code`                                                           AS `dockpoint_code`,
       `ods_prod`.`ediasnpackage`.`createdAt`                                                  AS `asn_created_at`,
       `ods_prod`.`ediasnpackage`.`createdAt`                                                  AS `created_at`,
       `ods_prod`.`ediasnpackage`.`updatedAt`                                                  AS `updatedat`
from (((((((`ods_prod`.`ediasnpackage` left join `ods_prod`.`part` on ((`ods_prod`.`ediasnpackage`.`partId` = `ods_prod`.`part`.`id`))) left join `ods_prod`.`ediasndeliverynode` on ((
        `ods_prod`.`ediasnpackage`.`ediDeliveryNodeId` =
        `ods_prod`.`ediasndeliverynode`.`id`))) left join `ods_prod`.`ediasntransport` on ((
        `ods_prod`.`ediasnpackage`.`ediAsnTransportId` =
        `ods_prod`.`ediasntransport`.`id`))) left join `ods_prod`.`supplier` on ((`ods_prod`.`ediasnpackage`.`supplierId` = `ods_prod`.`supplier`.`id`))) left join `ods_prod`.`whouse` on ((
        `ods_prod`.`ediasnpackage`.`currentWhouseId` =
        `ods_prod`.`whouse`.`id`))) left join `ods_prod`.`dockpoint` on ((
        `ods_prod`.`ediasnpackage`.`currentDockPointId` = `ods_prod`.`dockpoint`.`id`)))
         left join `ods_prod`.`user` on ((`ods_prod`.`ediasnpackage`.`receiverId` = `ods_prod`.`user`.`id`)));

