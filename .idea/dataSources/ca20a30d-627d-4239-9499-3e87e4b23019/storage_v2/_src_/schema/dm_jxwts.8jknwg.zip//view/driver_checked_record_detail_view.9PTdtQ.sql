create definer = root@`%` view driver_checked_record_detail_view as
select `ods_prod`.`drivercheckedrecord`.`id`               AS `id`,
       `ods_prod`.`user`.`name`                            AS `driver_name`,
       `ods_prod`.`user`.`nr`                              AS `driver_nr`,
       `ods_prod`.`cartroop`.`name`                        AS `cartroop_name`,
       `ods_prod`.`car`.`Nr`                               AS `car_nr`,
       `ods_prod`.`cartrailer`.`nr`                        AS `car_trailer_nr`,
       `src_whouse`.`name`                                 AS `source_whouse_name`,
       `dest_whouse`.`name`                                AS `destination_whouse_name`,
       `ods_prod`.`drivercheckedrecord`.`planTrayCount`    AS `plan_tray_count`,
       `ods_prod`.`drivercheckedrecord`.`planPackageCount` AS `plan_package_count`,
       `ods_prod`.`drivercheckedrecord`.`realTrayCount`    AS `real_tray_count`,
       `ods_prod`.`drivercheckedrecord`.`realPackageCount` AS `real_package_count`,
       `ods_prod`.`drivercheckedrecord`.`createdAt`        AS `created_at`
from ((((((((`ods_prod`.`drivercheckedrecord` left join `ods_prod`.`deliverynodecar` on ((
        `ods_prod`.`drivercheckedrecord`.`deliveryNodeCarId` =
        `ods_prod`.`deliverynodecar`.`id`))) left join `ods_prod`.`car` on ((`ods_prod`.`car`.`id` = `ods_prod`.`deliverynodecar`.`carId`))) left join `ods_prod`.`cartrailer` on ((
        `ods_prod`.`deliverynodecar`.`carTrailerId` =
        `ods_prod`.`cartrailer`.`id`))) left join `ods_prod`.`user` on ((`ods_prod`.`user`.`id` = `ods_prod`.`deliverynodecar`.`userId`))) left join `ods_prod`.`cartroop` on ((`ods_prod`.`cartroop`.`id` = `ods_prod`.`user`.`carTroopId`))) left join `ods_prod`.`deliverynode` on ((
        `ods_prod`.`drivercheckedrecord`.`deliveryNodeId` =
        `ods_prod`.`deliverynode`.`id`))) left join `ods_prod`.`whouse` `src_whouse` on ((`src_whouse`.`id` = `ods_prod`.`deliverynode`.`sourceWhouseId`)))
         left join `ods_prod`.`whouse` `dest_whouse`
                   on ((`dest_whouse`.`id` = `ods_prod`.`deliverynode`.`destinationWhouseId`)));

