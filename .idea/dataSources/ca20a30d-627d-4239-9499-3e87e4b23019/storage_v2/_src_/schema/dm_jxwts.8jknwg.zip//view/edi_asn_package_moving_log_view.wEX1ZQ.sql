create definer = root@`%` view edi_asn_package_moving_log_view as
select `ods_prod`.`ediasnpackagemovinglog`.`id`         AS `id`,
       `ods_prod`.`whouse`.`nr`                         AS `whouse_nr`,
       `ods_prod`.`ediasnpackagemovinglog`.`actionType` AS `action_type`,
       `creator`.`name`                                 AS `creator_name`,
       `ods_prod`.`car`.`Nr`                            AS `car_nr`,
       `ods_prod`.`user`.`name`                         AS `driver_name`,
       `ods_prod`.`user`.`phone`                        AS `driver_phone`,
       `ods_prod`.`ediasntransport`.`transportnumber`   AS `transport_nr`,
       `ods_prod`.`ediasndeliverynode`.`delnotenumber`  AS `delnote_number`,
       `ods_prod`.`ediasnpackage`.`nr`                  AS `edi_asn_package_nr`,
       `ods_prod`.`part`.`Nr`                           AS `part_nr`,
       `ods_prod`.`ediasnpackage`.`quantityperpack`     AS `quantity_perpack`,
       `ods_prod`.`ediasnpackage`.`supplierId`          AS `supplier_id`,
       `ods_prod`.`part`.`supplierCode`                 AS `supplier_code`,
       `ods_prod`.`dockpoint`.`code`                    AS `dockpoint_code`,
       `ods_prod`.`ediasntransport`.`arrivaldate`       AS `arrival_date`,
       `ods_prod`.`ediasnpackagemovinglog`.`createdAt`  AS `created_at`
from (((((((((`ods_prod`.`ediasnpackagemovinglog` left join `ods_prod`.`whouse` on ((
        `ods_prod`.`ediasnpackagemovinglog`.`whouseId` =
        `ods_prod`.`whouse`.`id`))) left join `ods_prod`.`car` on ((`ods_prod`.`ediasnpackagemovinglog`.`carId` = `ods_prod`.`car`.`id`))) left join `ods_prod`.`user` on ((
        `ods_prod`.`ediasnpackagemovinglog`.`driverId` =
        `ods_prod`.`user`.`id`))) left join `ods_prod`.`user` `creator` on ((`ods_prod`.`ediasnpackagemovinglog`.`creatorId` = `creator`.`id`))) left join `ods_prod`.`ediasnpackage` on ((
        `ods_prod`.`ediasnpackagemovinglog`.`packageId` =
        `ods_prod`.`ediasnpackage`.`id`))) left join `ods_prod`.`ediasntransport` on ((
        `ods_prod`.`ediasnpackage`.`ediAsnTransportId` =
        `ods_prod`.`ediasntransport`.`id`))) left join `ods_prod`.`ediasndeliverynode` on ((
        `ods_prod`.`ediasnpackage`.`ediDeliveryNodeId` =
        `ods_prod`.`ediasndeliverynode`.`id`))) left join `ods_prod`.`dockpoint` on ((
        `ods_prod`.`ediasnpackage`.`dockPointId` = `ods_prod`.`dockpoint`.`id`)))
         left join `ods_prod`.`part` on ((`ods_prod`.`ediasnpackage`.`partId` = `ods_prod`.`part`.`id`)));

