
CREATE VIEW [dbo].[DeliveryReceivedEdiPackageRelationView]
AS
SELECT     dbo.EdiAsnPackage.dockPointId, dbo.EdiAsnPackage.delivDate, dbo.DeliveryReceivedEdiPackageRelation.*, dbo.EdiAsnPackage.nr, dbo.EdiAsnPackage.ediAsnTransportId, 
                      dbo.EdiAsnPackage.ediDeliveryNodeId, dbo.EdiAsnPackage.internalid, dbo.EdiAsnPackage.parentid, dbo.EdiAsnPackage.quantityperpack, dbo.EdiAsnPackage.tara, 
                      dbo.EdiAsnPackage.itemnopackcustomer, dbo.EdiAsnPackage.itemnopacksupplier, dbo.EdiAsnPackage.ownership, dbo.EdiAsnPackage.recycling, dbo.EdiAsnPackage.batchno, 
                      dbo.EdiAsnPackage.klt, dbo.EdiAsnPackage.printflag, dbo.EdiAsnPackage.packagetype, dbo.EdiAsnPackage.delnotepositionid, dbo.EdiAsnPackage.quantitypack, dbo.EdiAsnPackage.labelnofrom, 
                      dbo.EdiAsnPackage.partId, dbo.EdiAsnPackage.stacking, dbo.EdiAsnPackage.orderno, dbo.EdiAsnPackage.supplierId, dbo.EdiAsnPackage.milkDate, dbo.EdiAsnPackage.parentPackageId, 
                      dbo.EdiAsnPackage.parentPathIds, dbo.EdiAsnPackage.state, dbo.EdiAsnPackage.currentWhouseId, dbo.EdiAsnPackage.currentDockPointId, dbo.EdiAsnPackage.currentUserId, 
                      dbo.EdiAsnPackage.currentCarId, dbo.EdiAsnPackage.currentCarTrailerId, dbo.EdiAsnPackage.isChecked, dbo.EdiAsnPackage.checkedAt, dbo.EdiAsnPackage.checkUserId, 
                      dbo.EdiAsnPackage.checkCarId, dbo.EdiAsnPackage.checkCarTrailerId, dbo.EdiAsnPackage.lastDeliveryPackageRelationId, dbo.EdiAsnPackage.sentAt, dbo.EdiAsnPackage.receivedAt, 
                      dbo.EdiAsnPackage.dataSourceType, dbo.EdiAsnPackage.ediAsnPositionId, dbo.EdiAsnPackage.createdAt, dbo.EdiAsnPackage.updatedAt
FROM         dbo.DeliveryReceivedEdiPackageRelation LEFT OUTER JOIN
                      dbo.EdiAsnPackage ON dbo.DeliveryReceivedEdiPackageRelation.ediAsnPackageId = dbo.EdiAsnPackage.id

go

