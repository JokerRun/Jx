CREATE VIEW [dbo].[CarTroopDetailView]
AS
SELECT     dbo.CarTroop.id, dbo.CarTroop.name, dbo.CarTroop.code, dbo.CarTroop.description, dbo.CarTroop.leader, dbo.CarTroop.carAreaId, dbo.CarArea.name AS carAreaName,
                       dbo.CarArea.code AS carAreaCode, dbo.[User].nr AS userNr, dbo.[User].name AS userName, dbo.[User].email AS userEmail, dbo.[User].phone AS userPhone, 
                      dbo.[User].roleType AS userRoleType
FROM         dbo.CarTroop LEFT OUTER JOIN
                      dbo.CarArea ON dbo.CarTroop.carAreaId = dbo.CarArea.id LEFT OUTER JOIN
                      dbo.[User] ON dbo.CarTroop.leader = dbo.[User].id
go

