
CREATE VIEW [dbo].[PackageAccountReportView]
AS
SELECT     dbo.EdiAsnDeliveryNode.delnotenumber AS asnDeliveryNodeNr, dbo.EdiAsnTransport.transportnumber AS asnTransportNr, dbo.EdiAsnTransport.arrivaldate AS asnArrivalDate, 
                      dbo.EdiAsnPackage.id, dbo.EdiAsnPackage.nr, dbo.EdiAsnPackage.ediAsnTransportId, dbo.EdiAsnPackage.ediDeliveryNodeId, dbo.EdiAsnPackage.internalid, dbo.EdiAsnPackage.parentid, 
                      dbo.EdiAsnPackage.quantityperpack, dbo.EdiAsnPackage.tara, dbo.EdiAsnPackage.itemnopackcustomer, dbo.EdiAsnPackage.itemnopacksupplier, dbo.EdiAsnPackage.ownership, 
                      dbo.EdiAsnPackage.recycling, dbo.EdiAsnPackage.batchno, dbo.EdiAsnPackage.klt, dbo.EdiAsnPackage.printflag, dbo.EdiAsnPackage.packagetype, dbo.EdiAsnPackage.delnotepositionid, 
                      dbo.EdiAsnPackage.quantitypack, dbo.EdiAsnPackage.labelnofrom, dbo.EdiAsnPackage.stacking, dbo.EdiAsnPackage.partId, dbo.EdiAsnPackage.orderno, dbo.EdiAsnPackage.supplierId, 
                      dbo.EdiAsnPackage.milkDate, dbo.EdiAsnPackage.parentPackageId, dbo.EdiAsnPackage.parentPathIds, dbo.EdiAsnPackage.state, dbo.EdiAsnPackage.currentWhouseId, 
                      dbo.EdiAsnPackage.currentDockPointId, dbo.EdiAsnPackage.currentUserId, dbo.EdiAsnPackage.currentCarId, dbo.EdiAsnPackage.currentCarTrailerId, dbo.EdiAsnPackage.isChecked, 
                      dbo.EdiAsnPackage.checkedAt, dbo.EdiAsnPackage.checkUserId, dbo.EdiAsnPackage.checkCarId, dbo.EdiAsnPackage.checkCarTrailerId, dbo.EdiAsnPackage.lastDeliveryPackageRelationId, 
                      dbo.EdiAsnPackage.sentAt, dbo.EdiAsnPackage.receivedAt, dbo.EdiAsnPackage.dataSourceType, dbo.EdiAsnPackage.ediAsnPositionId, dbo.EdiAsnPackage.createdAt, 
                      dbo.EdiAsnPackage.updatedAt, dbo.EdiAsnPackage.dockPointId, dbo.EdiAsnPackage.delivDate, dbo.Part.Nr AS partNr, dbo.DockPoint.code AS dockPointCode, dbo.Whouse.nr AS whouseNr, 
                      dbo.Whouse.name AS whouseName, dbo.Whouse.address AS whouseAddress, dbo.Supplier.name AS supplierName, dbo.Supplier.code AS supplierCode, dbo.Supplier.description AS supplierDesc, 
                      dbo.Supplier.address AS supplierAddress, dbo.Supplier.city AS supplierCity, dbo.EdiAsnDeliveryNode.delnotedate, dbo.EdiAsnPackage.isSAPReceived, dbo.EdiAsnPackage.sapReceivedAt, 
                      dbo.EdiAsnPackage.receiverId, dbo.Part.kltContent, dbo.Part.kltLength, dbo.Part.kltWidth, dbo.Part.kltHeight, dbo.Part.luContent, dbo.Part.luLength, dbo.Part.luWidth, dbo.Part.luHeight, 
                      dbo.Part.grossWeight, dbo.Part.tareWeight, dbo.EdiAsnPackage.totalQty, dbo.EdiAsnTransport.isVerify
FROM         dbo.EdiAsnPackage LEFT OUTER JOIN
                      dbo.Part ON dbo.EdiAsnPackage.partId = dbo.Part.id LEFT OUTER JOIN
                      dbo.EdiAsnDeliveryNode ON dbo.EdiAsnPackage.ediDeliveryNodeId = dbo.EdiAsnDeliveryNode.id LEFT OUTER JOIN
                      dbo.EdiAsnTransport ON dbo.EdiAsnPackage.ediAsnTransportId = dbo.EdiAsnTransport.id LEFT OUTER JOIN
                      dbo.Supplier ON dbo.EdiAsnPackage.supplierId = dbo.Supplier.id LEFT OUTER JOIN
                      dbo.Whouse ON dbo.EdiAsnPackage.currentWhouseId = dbo.Whouse.id LEFT OUTER JOIN
                      dbo.DockPoint ON dbo.EdiAsnPackage.currentDockPointId = dbo.DockPoint.id

go

