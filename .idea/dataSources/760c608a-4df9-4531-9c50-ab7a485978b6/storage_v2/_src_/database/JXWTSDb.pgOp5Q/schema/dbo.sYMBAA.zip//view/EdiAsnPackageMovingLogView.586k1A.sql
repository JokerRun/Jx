
CREATE VIEW [dbo].[EdiAsnPackageMovingLogView]
AS
SELECT     dbo.EdiAsnPackageMovingLog.id, dbo.EdiAsnPackageMovingLog.packageId, dbo.EdiAsnPackageMovingLog.whouseId, dbo.EdiAsnPackageMovingLog.carId, dbo.EdiAsnPackageMovingLog.driverId, 
                      dbo.EdiAsnPackageMovingLog.creatorId, dbo.EdiAsnPackageMovingLog.createdAt, dbo.EdiAsnPackageMovingLog.actionType, dbo.EdiAsnPackageMovingLog.relationId, 
                      dbo.EdiAsnPackage.nr AS ediAsnPackageNr, dbo.EdiAsnPackage.ediAsnTransportId, dbo.EdiAsnPackage.ediDeliveryNodeId, dbo.EdiAsnPackage.quantityperpack, dbo.EdiAsnPackage.packagetype, 
                      dbo.EdiAsnPackage.quantitypack, dbo.EdiAsnPackage.partId, dbo.EdiAsnPackage.orderno, dbo.EdiAsnPackage.supplierId, dbo.EdiAsnPackage.milkDate, dbo.EdiAsnPackage.parentPackageId, 
                      dbo.EdiAsnPackage.state, dbo.EdiAsnPackage.dataSourceType, dbo.EdiAsnPackage.dockPointId, dbo.EdiAsnPackage.delivDate, dbo.EdiAsnDeliveryNode.delnotenumber, 
                      dbo.DockPoint.code AS dockPointCode, dbo.Part.Nr AS partNr, dbo.Part.supplierCode, dbo.Whouse.nr AS whouseNr, dbo.Whouse.name AS whouseName, dbo.Car.Nr AS carNr, 
                      dbo.[User].phone AS driverPhone, dbo.[User].name AS driverName, Creator.name AS creatorName, Creator.phone AS creatorPhone, dbo.EdiAsnTransport.transportnumber AS transportNr, 
                      dbo.EdiAsnTransport.arrivaldate AS arrivalDate
FROM         dbo.EdiAsnPackageMovingLog LEFT OUTER JOIN
                      dbo.Whouse ON dbo.EdiAsnPackageMovingLog.whouseId = dbo.Whouse.id LEFT OUTER JOIN
                      dbo.Car ON dbo.EdiAsnPackageMovingLog.carId = dbo.Car.id LEFT OUTER JOIN
                      dbo.[User] ON dbo.EdiAsnPackageMovingLog.driverId = dbo.[User].id LEFT OUTER JOIN
                      dbo.[User] AS Creator ON dbo.EdiAsnPackageMovingLog.creatorId = Creator.id LEFT OUTER JOIN
                      dbo.EdiAsnPackage ON dbo.EdiAsnPackageMovingLog.packageId = dbo.EdiAsnPackage.id LEFT OUTER JOIN
                      dbo.EdiAsnTransport ON dbo.EdiAsnPackage.ediAsnTransportId = dbo.EdiAsnTransport.id LEFT OUTER JOIN
                      dbo.EdiAsnDeliveryNode ON dbo.EdiAsnPackage.ediDeliveryNodeId = dbo.EdiAsnDeliveryNode.id LEFT OUTER JOIN
                      dbo.DockPoint ON dbo.EdiAsnPackage.dockPointId = dbo.DockPoint.id LEFT OUTER JOIN
                      dbo.Part ON dbo.EdiAsnPackage.partId = dbo.Part.id

go

