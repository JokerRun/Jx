CREATE VIEW [dbo].[DriverDeliveryNodeView]
AS
SELECT     dbo.DeliveryNodeCar.id, dbo.DeliveryNodeCar.carId, dbo.DeliveryNodeCar.userId, dbo.DeliveryNodeCar.carTrailerId, dbo.DeliveryNodeCar.deliveryNodeId, dbo.DeliveryNodeCar.createdAt, 
                      dbo.DeliveryNodeCar.updatedAt, dbo.DeliveryNodeCar.isInStnDeliver, dbo.DeliveryNodeCar.isSent, dbo.DeliveryNodeCar.sentAt, dbo.DeliveryNodeCar.isReceived, dbo.DeliveryNodeCar.receivedAt, 
                      dbo.DeliveryNodeCar.isPickOver, dbo.DeliveryNodeCar.pickOverAt, dbo.DeliveryNodeCar.state, dbo.DeliveryNode.nr AS deliveryNodeNr, 
                      dbo.DeliveryNode.sourceWhouseId AS deliveryNodeSourceWhouseId, dbo.DeliveryNode.destinationWhouseId AS deliveryNodeDestinationWhouseId, 
                      dbo.DeliveryNode.currentWhouseId AS deliveryNodeCurrentWhouseId, dbo.DeliveryNode.state AS deliveryNodeState, dbo.DeliveryNode.createdAt AS deliveryNodeCreatedAt, 
                      dbo.DeliveryNode.updatedAt AS deliveryNodeUpdatedAt, dbo.DeliveryNode.createUserId AS deliveryNodeCreateUserId, dbo.DeliveryNode.isCarTroopDelivery AS deliveryNodeIsCarTroopDelivery, 
                      dbo.DeliveryNode.carTroopId AS deliveryNodeCarTroopId, dbo.DeliveryNode.shouldSentArrivalDateTime AS deliveryNodeShouldSentArrivalDateTime, 
                      dbo.DeliveryNode.goToPickDateTime AS deliveryNodeGoToPickDateTime, dbo.DeliveryNode.deliveryMode AS deliveryNodeDeliveryMode, 
                      dbo.DeliveryNode.stowageCarRemark AS deliveryNodeStowageCarRemark, dbo.DeliveryNode.isSent AS deliveryNodeIsSent, dbo.DeliveryNode.sentAt AS deliveryNodeSentAt, 
                      dbo.DeliveryNode.isReceived AS deliveryNodeIsReceived, dbo.DeliveryNode.receivedAt AS deliveryNodeReceivedAt, dbo.DeliveryNode.isPickOver AS deliveryNodeIsPickOver, 
                      dbo.DeliveryNode.pickOverAt AS deliveryNodePickOverAt
FROM         dbo.DeliveryNodeCar INNER JOIN
                      dbo.DeliveryNode ON dbo.DeliveryNodeCar.deliveryNodeId = dbo.DeliveryNode.id
go

