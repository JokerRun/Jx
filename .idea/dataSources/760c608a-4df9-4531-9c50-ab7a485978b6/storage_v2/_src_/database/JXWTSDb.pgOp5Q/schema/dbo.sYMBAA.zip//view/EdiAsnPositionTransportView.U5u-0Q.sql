CREATE VIEW [dbo].[EdiAsnPositionTransportView]
AS
SELECT     dbo.EdiAsnPosition.id, dbo.EdiAsnPosition.ediAsnTransportId, dbo.EdiAsnPosition.ediAsnDeliveryNodeId, dbo.EdiAsnPosition.positionId, dbo.EdiAsnPosition.quantity, dbo.EdiAsnPosition.weightnet, 
                      dbo.EdiAsnPosition.weightgross, dbo.EdiAsnPosition.packedquantity, dbo.EdiAsnPosition.customeridentifier, dbo.EdiAsnPosition.remark, dbo.EdiAsnPosition.ordertype, dbo.EdiAsnPosition.orderno, 
                      dbo.EdiAsnPosition.orderpos, dbo.EdiAsnPosition.itemnocustomer, dbo.EdiAsnPosition.itemnosupplier, dbo.EdiAsnPosition.itemdesccustomer, dbo.EdiAsnPosition.uom, 
                      dbo.EdiAsnPosition.consignment, dbo.EdiAsnPosition.storage, dbo.EdiAsnPosition.pointofuse, dbo.EdiAsnPosition.applicationkey, dbo.EdiAsnPosition.batchno, dbo.EdiAsnPosition.engchglevel, 
                      dbo.EdiAsnPosition.countryoforigin, dbo.EdiAsnPosition.dangerousgoods, dbo.EdiAsnPosition.bondedgoods, dbo.EdiAsnPosition.createdAt, dbo.EdiAsnPosition.updatedAt, 
                      dbo.EdiAsnPosition.dataSourceType, dbo.EdiAsnPosition.trayCount, dbo.EdiAsnPosition.packageCount, dbo.EdiAsnPosition.partId, dbo.EdiAsnPosition.partNr, dbo.EdiAsnTransport.plantname, 
                      dbo.EdiAsnTransport.plantcode, dbo.EdiAsnTransport.customername, dbo.EdiAsnTransport.customerno, dbo.EdiAsnTransport.customerdock, dbo.EdiAsnTransport.suppliername, 
                      dbo.EdiAsnTransport.supplierno, dbo.EdiAsnTransport.arrivaldateDatetime, dbo.EdiAsnTransport.arrivaldate
FROM         dbo.EdiAsnPosition LEFT OUTER JOIN
                      dbo.EdiAsnTransport ON dbo.EdiAsnPosition.ediAsnTransportId = dbo.EdiAsnTransport.id
go

