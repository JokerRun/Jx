CREATE VIEW [dbo].[SupplierOnSupplierAreaView]
AS
SELECT    dbo.Supplier.id AS id,dbo.Supplier.name AS name, dbo.Supplier.code AS code, dbo.Supplier.description AS description, dbo.Supplier.address AS address, dbo.Supplier.city AS city, 
                      dbo.SupplierArea.name AS SupplierAreaName
FROM         dbo.Supplier LEFT OUTER JOIN
                      dbo.SupplierArea ON dbo.Supplier.supplierAreaCode = dbo.SupplierArea.code
go

