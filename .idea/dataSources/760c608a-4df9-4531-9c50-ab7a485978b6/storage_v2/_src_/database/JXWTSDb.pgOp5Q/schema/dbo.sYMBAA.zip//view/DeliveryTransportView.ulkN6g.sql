
CREATE VIEW [dbo].[DeliveryTransportView]
AS
SELECT     dbo.EdiAsnTransport.id, dbo.EdiAsnTransport.transportnumber, dbo.EdiAsnTransport.state, dbo.EdiAsnTransport.arrivaldateDatetime, dbo.EdiAsnTransport.createdDateTime, 
                      dbo.EdiAsnTransport.currentWhouseId, dbo.DeliveryNodeEdiTransRelation.deliveryNodeId, dbo.EdiAsnTransport.customerdock, dbo.EdiAsnTransport.dockPointId, dbo.EdiAsnTransport.supplierId, 
                      dbo.DeliveryNode.nr AS deliveryNodeNr, dbo.DeliveryNode.destinationWhouseId AS deliveryNodeDestinationWhouseId, dbo.DeliveryNode.currentWhouseId AS deliveryNodeCurrentWhouseId, 
                      dbo.DeliveryNode.state AS deliveryNodeState, dbo.DeliveryNode.sentAt AS deliveryNodeSentAt, dbo.DeliveryNode.isCarTroopDelivery AS deliveryNodeIsCarTroopDelivery, 
                      dbo.DeliveryNode.carTroopId AS deliveryNodeCarTroopId, dbo.DeliveryNodeEdiTransRelation.id AS devlieryNodeTransportRelationId, dbo.Supplier.name AS supplierName, 
                      dbo.Supplier.code AS supplierCode, dbo.Supplier.address AS supplierAddress, dbo.Supplier.city AS supplierCity, dbo.Supplier.linkMan AS supplierLinkMan, 
                      dbo.Supplier.linkPhone AS supplierLinkPhone, dbo.Supplier.description AS supplierDescription, dbo.DockPoint.code AS dockPointCode
FROM         dbo.EdiAsnTransport INNER JOIN
                      dbo.DeliveryNodeEdiTransRelation ON dbo.EdiAsnTransport.id = dbo.DeliveryNodeEdiTransRelation.ediAsnTransportId INNER JOIN
                      dbo.DeliveryNode ON dbo.DeliveryNodeEdiTransRelation.deliveryNodeId = dbo.DeliveryNode.id LEFT OUTER JOIN
                      dbo.Supplier ON dbo.EdiAsnTransport.supplierno = dbo.Supplier.code LEFT OUTER JOIN
                      dbo.DockPoint ON dbo.EdiAsnTransport.dockPointId = dbo.DockPoint.id

go

