
CREATE VIEW [dbo].[DeliveryScheduleDetailView]
AS
SELECT     dbo.DeliverySchedule.id, dbo.DeliverySchedule.transportNmae, dbo.DeliverySchedule.email, dbo.DeliverySchedule.status, dbo.DeliverySchedule.changeReason, 
                      dbo.DeliverySchedule.orderNumber, dbo.DeliverySchedule.milkRunDate, dbo.DeliverySchedule.supplierId, dbo.DeliverySchedule.partId, dbo.DeliverySchedule.qty, 
                      dbo.DeliverySchedule.dockPointId, dbo.DeliverySchedule.boxQty, dbo.DeliverySchedule.palletQty, dbo.DeliverySchedule.state, dbo.DeliverySchedule.hasAsn, dbo.DeliverySchedule.asnQty, 
                      dbo.DockPoint.name AS DockPointName, dbo.DockPoint.code AS DockPointCode, dbo.Part.Nr AS PartNr, dbo.Supplier.name AS SupplierName, dbo.Supplier.code AS SupplierCode, 
                      dbo.Part.kltContent, dbo.Part.kltLength, dbo.Part.kltWidth, dbo.Part.kltHeight, dbo.Part.luContent, dbo.Part.luLength, dbo.Part.luWidth, dbo.Part.luHeight, dbo.Part.grossWeight, dbo.Part.weight, 
                      dbo.Part.tareWeight, dbo.Part.weightUnit, dbo.Part.unitsPerPallet, dbo.Part.unitsPerLayer, dbo.Part.layers, dbo.Part.palletStackingLayers, dbo.Part.packageType, dbo.Part.packageCategory, 
                      dbo.Part.packagingMaterialType, dbo.Part.isWithWheels, dbo.Part.isFolding, dbo.Part.lengthAfterFolding, dbo.Part.widthAfterFolding, dbo.Part.heightAfterFolding, dbo.Part.packagingAmount, 
                      dbo.Part.isWithReturnable, dbo.Part.isPackageReturnable, dbo.Part.isPalletReturnable, dbo.Part.isLidReturnable, dbo.Part.mainCode, dbo.Part.PalletCode, dbo.Part.isPI, dbo.Part.lidCode, 
                      dbo.Part.isWPI, dbo.DeliverySchedule.isDispatched, dbo.DeliverySchedule.delivDate, dbo.DeliverySchedule.singlePackageCount, dbo.DeliverySchedule.upPartNr, 
                      dbo.DeliverySchedule.usedLength, dbo.Supplier.description AS SupplierDescription, dbo.Supplier.address AS SupplierAddress, dbo.Supplier.city AS SupplierCity, 
                      dbo.Supplier.linkMan AS SupplierLinkMan, dbo.Supplier.linkPhone AS SupplierLinkPhone, dbo.DeliverySchedule.orderListId, dbo.DeliverySchedule.plant
FROM         dbo.DeliverySchedule LEFT OUTER JOIN
                      dbo.DockPoint ON dbo.DeliverySchedule.dockPointId = dbo.DockPoint.id LEFT OUTER JOIN
                      dbo.Part ON dbo.DeliverySchedule.partId = dbo.Part.id LEFT OUTER JOIN
                      dbo.Supplier ON dbo.DeliverySchedule.supplierId = dbo.Supplier.id

go

