

CREATE VIEW [dbo].[EdiAsnTransportView]
AS
SELECT     dbo.EdiAsnTransport.*, dbo.Supplier.name, dbo.Supplier.code, dbo.Supplier.description, dbo.Supplier.city, dbo.Supplier.address, dbo.Supplier.supplierAreaCode, dbo.Supplier.milkRunDatePre, 
                      dbo.Supplier.linkMan, dbo.Supplier.linkPhone, dbo.Supplier.allowPickTime, dbo.Supplier.allowMaxCarTypeId, dbo.Supplier.workTime, dbo.Supplier.linkMan1, dbo.Supplier.mrperId, 
                      dbo.Supplier.linkPhone2, dbo.Supplier.planTime, dbo.Supplier.planCountPer, dbo.Supplier.planFrequency, dbo.Supplier.ediId, dbo.Supplier.ediPwd, dbo.Supplier.qcId
FROM         dbo.EdiAsnTransport INNER JOIN
                      dbo.Supplier ON dbo.EdiAsnTransport.supplierId = dbo.Supplier.id


go

