
CREATE VIEW [dbo].[DeliveryNodePackageView]
AS
SELECT     dbo.DeliveryNodeEdiPackageRelation.deliveryNodeId, dbo.DeliveryNodeEdiPackageRelation.ediAsnPackageId, dbo.DeliveryNode.nr, dbo.DeliveryNode.sourceWhouseId, 
                      dbo.DeliveryNode.destinationWhouseId, dbo.DeliveryNode.currentWhouseId, dbo.DeliveryNode.state, dbo.DeliveryNode.createdAt, dbo.DeliveryNode.updatedAt, dbo.DeliveryNode.createUserId, 
                      dbo.DeliveryNode.shouldSentArrivalDateTime, dbo.DeliveryNode.goToPickDateTime, dbo.DeliveryNode.deliveryMode, dbo.DeliveryNode.isPickOver, dbo.DeliveryNode.pickOverAt, 
                      dbo.DeliveryNode.isSent, dbo.DeliveryNode.sentAt, dbo.DeliveryNode.isReceived, dbo.DeliveryNode.receivedAt, dbo.DeliveryNode.supplierTrasnNr, dbo.DeliveryNode.stowageCarRemark, 
                      dbo.DeliveryNode.isCarTroopDelivery, dbo.DeliveryNode.carTroopId, dbo.EdiAsnPackage.nr AS packageNr, dbo.EdiAsnPackage.partId, dbo.EdiAsnPackage.supplierId, dbo.EdiAsnPackage.milkDate, 
                      dbo.EdiAsnPackage.delivDate, dbo.EdiAsnPackage.dockPointId, dbo.EdiAsnPackage.currentDockPointId, dbo.EdiAsnPackage.currentWhouseId AS packCurrentWhouse, 
                      dbo.EdiAsnPackage.state AS packState, dbo.EdiAsnPackage.orderno, dbo.EdiAsnPackage.packagetype, dbo.EdiAsnPackage.quantityperpack, dbo.EdiAsnPackage.quantitypack, 
                      dbo.EdiAsnPackage.parentPackageId
FROM         dbo.DeliveryNodeEdiPackageRelation INNER JOIN
                      dbo.DeliveryNode ON dbo.DeliveryNodeEdiPackageRelation.deliveryNodeId = dbo.DeliveryNode.id INNER JOIN
                      dbo.EdiAsnPackage ON dbo.DeliveryNodeEdiPackageRelation.ediAsnPackageId = dbo.EdiAsnPackage.id

go

