CREATE VIEW dbo.DeliveryNodeSchedule
AS
SELECT     dbo.DeliveryNode.nr, dbo.DeliveryNode.sourceWhouseId, dbo.DeliveryNode.destinationWhouseId, dbo.DeliveryNode.state, dbo.DeliveryNode.createdAt, dbo.DeliveryNode.currentWhouseId, 
                      dbo.DeliveryNode.updatedAt, dbo.DeliveryNode.createUserId, dbo.DeliveryNode.isCarTroopDelivery, dbo.DeliveryNode.carTroopId, dbo.DeliveryNode.shouldSentArrivalDateTime, 
                      dbo.DeliveryNode.goToPickDateTime, dbo.DeliveryNode.deliveryMode, dbo.DeliveryNode.isPickOver, dbo.DeliveryNode.pickOverAt, dbo.DeliveryNode.sentAt, dbo.DeliveryNode.isSent, 
                      dbo.DeliveryNode.isReceived, dbo.DeliveryNode.receivedAt, dbo.DeliveryNode.stowageCarRemark, dbo.DeliveryNode.supplierTrasnNr, dbo.DeliverySchedule.orderNumber, 
                      dbo.DeliverySchedule.milkRunDate, dbo.DeliverySchedule.supplierId, dbo.DeliverySchedule.partId, dbo.DeliverySchedule.plant, dbo.DeliverySchedule.qty, dbo.DeliverySchedule.boxQty, 
                      dbo.DeliverySchedule.dockPointId, dbo.DeliverySchedule.palletQty, dbo.DeliverySchedule.delivDate, dbo.DeliverySchedule.singlePackageCount, dbo.DeliverySchedule.usedLength, 
                      dbo.DeliveryNodeScheduleRelation.deliveryNodeId, dbo.DeliveryNodeScheduleRelation.deliveryScheduleId, dbo.DeliveryNodeScheduleRelation.id, dbo.Supplier.name, dbo.Supplier.code, 
                      dbo.Supplier.description, dbo.Supplier.address, dbo.Supplier.city, dbo.Part.Nr AS partNr, dbo.Part.kltContent, dbo.Part.kltLength, dbo.Part.kltWidth, dbo.Part.kltHeight, dbo.Part.luContent, 
                      dbo.Part.luLength, dbo.Part.luWidth, dbo.Part.luHeight, dbo.Part.unitsPerPallet, dbo.Part.unitsPerLayer, dbo.Part.tareWeight
FROM         dbo.DeliveryNodeScheduleRelation INNER JOIN
                      dbo.DeliveryNode ON dbo.DeliveryNodeScheduleRelation.deliveryNodeId = dbo.DeliveryNode.id INNER JOIN
                      dbo.DeliverySchedule ON dbo.DeliveryNodeScheduleRelation.id = dbo.DeliverySchedule.id INNER JOIN
                      dbo.Supplier ON dbo.DeliverySchedule.supplierId = dbo.Supplier.id INNER JOIN
                      dbo.Part ON dbo.DeliverySchedule.partId = dbo.Part.id AND dbo.Supplier.code = dbo.Part.supplierCode
go

