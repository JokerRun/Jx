CREATE VIEW [dbo].[DeliveryScheduleSupplierView]
AS
SELECT     dbo.Supplier.name AS SupplierName, dbo.Supplier.code AS SupplierCode, dbo.Supplier.description AS SupplierDescription, dbo.Supplier.address AS SupplierAddress, 
                      dbo.Supplier.city AS SupplierCity, dbo.Supplier.supplierAreaCode, dbo.DeliverySchedule.*
FROM         dbo.Supplier INNER JOIN
                      dbo.DeliverySchedule ON dbo.Supplier.id = dbo.DeliverySchedule.supplierId
go

