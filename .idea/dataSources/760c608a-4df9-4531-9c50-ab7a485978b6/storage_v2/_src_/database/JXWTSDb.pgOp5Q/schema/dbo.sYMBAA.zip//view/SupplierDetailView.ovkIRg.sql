
CREATE VIEW [dbo].[SupplierDetailView]
AS
SELECT     dbo.Supplier.id, dbo.Supplier.name, dbo.Supplier.code, dbo.Supplier.description, dbo.Supplier.address, dbo.Supplier.city, dbo.Supplier.supplierAreaCode, dbo.Supplier.milkRunDatePre, 
                      dbo.Supplier.linkMan, dbo.Supplier.linkPhone, dbo.Supplier.linkMan1, dbo.Supplier.linkPhone2, dbo.Supplier.allowPickTime, dbo.Supplier.allowMaxCarTypeId, dbo.Supplier.workTime, 
                      dbo.Supplier.mrperId, dbo.Supplier.planTime, dbo.Supplier.planCountPer, dbo.Supplier.planFrequency, dbo.Supplier.ediId, dbo.Supplier.ediPwd, dbo.SupplierArea.name AS supplierAreaName, 
                      dbo.CarType.nr AS carTypeNr, dbo.CarType.name AS carTypeName, dbo.Mrper.mrpc AS mrperMrpc, dbo.Mrper.name AS mrperName, dbo.Mrper.phone AS mrperPhone, 
                      dbo.Mrper.groupName AS mrperGroupName, dbo.Mrper.telephone AS mrperTelephone, dbo.Mrper.email AS mrperEmail, dbo.Supplier.qcId, dbo.[User].nr AS qcNr, dbo.[User].name AS qcName, 
                      dbo.[User].email AS qcEmail, dbo.[User].phone AS qcPhone, dbo.[User].roleType AS qcRoleType
FROM         dbo.Supplier LEFT OUTER JOIN
                      dbo.[User] ON dbo.Supplier.qcId = dbo.[User].id LEFT OUTER JOIN
                      dbo.SupplierArea ON dbo.Supplier.supplierAreaCode = dbo.SupplierArea.code LEFT OUTER JOIN
                      dbo.CarType ON dbo.Supplier.allowMaxCarTypeId = dbo.CarType.id LEFT OUTER JOIN
                      dbo.Mrper ON dbo.Supplier.mrperId = dbo.Mrper.id

go

