
CREATE VIEW [dbo].[DeliveryNodeCarView]
AS
SELECT     dbo.DeliveryNodeCar.id, dbo.DeliveryNodeCar.carId, dbo.DeliveryNodeCar.userId, dbo.DeliveryNodeCar.carTrailerId, dbo.DeliveryNodeCar.deliveryNodeId, dbo.DeliveryNodeCar.createdAt, 
                      dbo.DeliveryNodeCar.updatedAt, dbo.DeliveryNodeCar.isInStnDeliver, dbo.Car.Nr AS carNr, dbo.Car.status AS carStatus, dbo.Car.carAreaCode, dbo.Car.carTroopCode, 
                      dbo.Car.driverId AS carDriverId, dbo.Car.description AS carDescription, dbo.Car.capacity AS carCapacity, dbo.[User].nr AS userNr, dbo.[User].name AS userName, dbo.[User].email AS userEmail, 
                      dbo.[User].phone AS userPhone, dbo.[User].roleType AS userRoleType, dbo.DeliveryNode.nr AS deliveryNodeNr, dbo.CarTrailer.nr AS carTrailerNr, cartype.nr AS carTypeNr, 
                      cartype.name AS carTypeName, cartype.type AS carTypeType, cartTrailerType.nr AS cartTrailerTypeNr, cartTrailerType.name AS cartTrailerTypeName, cartTrailerType.type AS cartTrailerTypeType, 
                      dbo.CarTroop.name AS carTroopName, dbo.CarTroop.id AS carTroopId, dbo.Car.carTypeId, dbo.Car.innerLength AS carInnerLength, dbo.Car.innerWidth AS carInnerWidth, 
                      dbo.Car.innerHeight AS carInnerHeight, dbo.CarTrailer.innerLength AS trailerInnerLength, dbo.CarTrailer.innerWidth AS trailerInnerWidth, dbo.CarTrailer.innerHeight AS trailerInnerHeight, 
                      dbo.CarTrailer.capacity AS trailerCapacity, dbo.CarTrailer.carTypeId AS trailerCarTypeId, dbo.CarTrailer.carTroopId AS trailerCarTroopId, dbo.CarTrailer.status AS trailerStatus
FROM         dbo.DeliveryNodeCar LEFT OUTER JOIN
                      dbo.Car ON dbo.DeliveryNodeCar.carId = dbo.Car.id LEFT OUTER JOIN
                      dbo.[User] ON dbo.DeliveryNodeCar.userId = dbo.[User].id INNER JOIN
                      dbo.DeliveryNode ON dbo.DeliveryNodeCar.deliveryNodeId = dbo.DeliveryNode.id LEFT OUTER JOIN
                      dbo.CarTrailer ON dbo.DeliveryNodeCar.carTrailerId = dbo.CarTrailer.id LEFT OUTER JOIN
                      dbo.CarType AS cartype ON cartype.id = dbo.Car.carTypeId LEFT OUTER JOIN
                      dbo.CarType AS cartTrailerType ON cartTrailerType.id = dbo.CarTrailer.carTypeId LEFT OUTER JOIN
                      dbo.CarTroop ON dbo.CarTroop.code = dbo.Car.carTroopCode

go

