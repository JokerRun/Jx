
CREATE VIEW [dbo].[DriverCheckedRecordDetailView]
AS
SELECT     dbo.DriverCheckedRecord.id, dbo.DriverCheckedRecord.deliveryNodeId, dbo.DriverCheckedRecord.deliveryNodeCarId, dbo.DriverCheckedRecord.ediAsnTransportId, 
                      dbo.DriverCheckedRecord.realTrayCount, dbo.DriverCheckedRecord.realPackageCount, dbo.DriverCheckedRecord.planTrayCount, dbo.DriverCheckedRecord.planPackageCount, 
                      dbo.DriverCheckedRecord.createdAt, dbo.DriverCheckedRecord.creatorId, dbo.[User].nr AS driverNr, dbo.[User].name AS driverName, dbo.[User].phone AS driverPhone, 
                      dbo.[User].roleType AS driverRoleType, dbo.Car.Nr AS carNr, dbo.CarTroop.name AS carTroopName, dbo.CarTroop.code AS carTroopCode, dbo.DeliveryNodeCar.carId, 
                      dbo.DeliveryNodeCar.carTrailerId, dbo.CarTroop.id AS carTroopId, dbo.[User].id AS driverId, dbo.DeliveryNode.sourceWhouseId, dbo.DeliveryNode.destinationWhouseId, 
                      SourceWhouse.nr AS sourceWhouseNr, SourceWhouse.name AS sourceWhouseName, DestinationWhouse.nr AS destinationWhouseNr, 
                      DestinationWhouse.name AS destinationWhouseName
FROM         dbo.DriverCheckedRecord LEFT OUTER JOIN
                      dbo.DeliveryNode ON dbo.DriverCheckedRecord.deliveryNodeId = dbo.DeliveryNode.id LEFT OUTER JOIN
                      dbo.DeliveryNodeCar ON dbo.DriverCheckedRecord.deliveryNodeCarId = dbo.DeliveryNodeCar.id LEFT OUTER JOIN
                      dbo.Car ON dbo.DeliveryNodeCar.carId = dbo.Car.id LEFT OUTER JOIN
                      dbo.[User] ON dbo.DeliveryNodeCar.userId = dbo.[User].id LEFT OUTER JOIN
                      dbo.CarTroop ON dbo.[User].carTroopId = dbo.CarTroop.id LEFT OUTER JOIN
                      dbo.Whouse AS SourceWhouse ON SourceWhouse.id = dbo.DeliveryNode.sourceWhouseId LEFT OUTER JOIN
                      dbo.Whouse AS DestinationWhouse ON DestinationWhouse.id = dbo.DeliveryNode.destinationWhouseId

go

