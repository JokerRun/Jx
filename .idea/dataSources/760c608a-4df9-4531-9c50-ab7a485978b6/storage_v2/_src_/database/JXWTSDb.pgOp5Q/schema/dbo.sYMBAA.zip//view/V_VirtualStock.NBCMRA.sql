


CREATE VIEW [dbo].[V_VirtualStock]
AS
SELECT  s.id ,
        s.whouseId ,
        w.name AS whouseName ,
        packageNr ,
        qty ,
        fifo ,
        partId ,
        p.Nr AS partName ,
        orderNr ,
        supplierId ,
        sup.description AS supplierName ,
        creator ,
        u.name AS creatorName ,
        createdAt ,
        updatedAt ,
        s.packageType ,
        parentPackageNr ,
        transportNr,
        tovirtual
FROM    dbo.Stock s
        LEFT JOIN dbo.Whouse w ON s.whouseId = w.id
        LEFT JOIN dbo.Supplier sup ON s.supplierId = sup.id
        LEFT JOIN dbo.Part p ON s.partId = p.id
        LEFT JOIN dbo.[User] u ON s.creator = u.id
		WHERE tovirtual = '1'


go

