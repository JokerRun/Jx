
CREATE VIEW [dbo].[EdiAsnPackageView]
AS
SELECT     p.id, p.nr, p.ediAsnTransportId, p.ediDeliveryNodeId, p.internalid, p.parentid, p.quantityperpack, p.tara, p.itemnopackcustomer, p.ownership, p.itemnopacksupplier, p.recycling, p.batchno, p.klt, 
                      p.printflag, p.packagetype, p.delnotepositionid, p.quantitypack, p.labelnofrom, p.stacking, p.partId, p.parentPackageId, p.state, p.parentPathIds, p.currentWhouseId, p.currentDockPointId, 
                      p.isChecked, p.checkedAt, p.checkUserId, p.checkCarId, p.checkCarTrailerId, p.lastDeliveryPackageRelationId, p.ediAsnPositionId, p.sentAt, p.receivedAt, p.dataSourceType, p.dockPointId, 
                      p.currentUserId, p.currentCarId, p.currentCarTrailerId, p.orderno, p.supplierId, p.milkDate, p.createdAt, p.updatedAt, dbo.Whouse.nr AS currentWhouseNr, dbo.Whouse.name AS currentWhouseName, 
                      dbo.Whouse.address AS currentWhouseAddress, dbo.Whouse.type AS currentWhouseType, dbo.Whouse.capacity AS currentWhouseTypeStr, dbo.Part.Nr AS partNr, 
                      dbo.Part.description AS partDescription, dbo.Part.supplierCode AS partSupplierCode, dbo.[User].nr AS checkUserNr, dbo.[User].name AS checkUserName, dbo.[User].email AS checkUserEmail, 
                      dbo.[User].phone AS checkUserPhone, dbo.[User].roleType AS checkUserRoleType, dbo.Car.Nr AS checkCarNr, dbo.Car.capacity AS checkCapacity, dbo.Car.description AS checkCarDescription, 
                      dbo.Car.status AS checkCarStatus, dbo.Car.carAreaCode, dbo.Car.carTroopCode, dbo.Car.driverId AS carDriverId, dbo.DockPoint.name AS currentDockPointName, 
                      dbo.DockPoint.code AS currentDockPointCode, dbo.DockPoint.description AS currentDockPointDescription, dbo.CarTrailer.nr AS checkCarTrailerNr, p.delivDate, CUser.name AS currUserName, 
                      CUser.nr AS currUserNr, CUser.email AS currUserEmail, CUser.phone AS currUserPhone, CUser.whouseId AS currUserWhouseId, CCar.Nr AS currCarNr, CCar.carTypeId AS currCarTypeId, 
                      CCar.status AS currCarStatus, CCarTrailer.nr AS currCarTrailerNr, CCarTrailer.status AS currCarTrailerStatus, CCarTrailer.carTypeId AS currCarTrailerTypeId, dbo.Part.kltContent, dbo.Part.kltLength, 
                      dbo.Part.kltWidth, dbo.Part.kltHeight, dbo.Part.luContent, dbo.Part.luLength, dbo.Part.luWidth, dbo.Part.luHeight, dbo.Part.grossWeight, dbo.Part.tareWeight, dbo.Part.weightUnit, 
                      dbo.Part.milkRunDatePre, dbo.Part.perPalletLength, dbo.Part.doublePalletCount, dbo.Part.deliveryFlodingLayers, dbo.EdiAsnTransport.transportnumber
FROM         dbo.EdiAsnPackage AS p LEFT OUTER JOIN
                      dbo.EdiAsnTransport ON p.ediAsnTransportId = dbo.EdiAsnTransport.id LEFT OUTER JOIN
                      dbo.[User] ON p.checkUserId = dbo.[User].id LEFT OUTER JOIN
                      dbo.Car ON p.checkCarId = dbo.Car.id LEFT OUTER JOIN
                      dbo.CarTrailer ON p.checkCarTrailerId = dbo.CarTrailer.id LEFT OUTER JOIN
                      dbo.Whouse ON p.currentWhouseId = dbo.Whouse.id LEFT OUTER JOIN
                      dbo.DockPoint ON p.currentDockPointId = dbo.DockPoint.id LEFT OUTER JOIN
                      dbo.Part ON p.partId = dbo.Part.id LEFT OUTER JOIN
                      dbo.[User] AS CUser ON CUser.id = p.currentUserId LEFT OUTER JOIN
                      dbo.Car AS CCar ON CCar.id = p.currentCarId LEFT OUTER JOIN
                      dbo.CarTrailer AS CCarTrailer ON CCarTrailer.id = p.currentCarTrailerId

go

