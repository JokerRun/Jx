
CREATE VIEW [dbo].[DriverCheckPackageView]
AS
SELECT     dbo.DeliveryNodeEdiPackageRelation.deliveryNodeId, dbo.DeliveryNodeEdiPackageRelation.ediAsnTransportId, dbo.DeliveryNodeEdiPackageRelation.id, 
                      dbo.DeliveryNodeEdiPackageRelation.ediAsnPackageId, dbo.DeliveryNodeEdiPackageRelation.checkedAt, dbo.DeliveryNodeEdiPackageRelation.checkUserId, 
                      dbo.DeliveryNodeEdiPackageRelation.checkCarId, dbo.DeliveryNodeEdiPackageRelation.createdAt, dbo.DeliveryNodeEdiPackageRelation.updatedAt, 
                      dbo.DeliveryNodeEdiPackageRelation.isChecked, dbo.DeliveryNodeEdiPackageRelation.checkCarTrailerId, dbo.EdiAsnPackage.parentPackageId, dbo.Part.Nr AS partNr, dbo.EdiAsnPackage.partId, 
                      dbo.EdiAsnPackage.nr AS packageNr, dbo.EdiAsnPackage.packagetype
FROM         dbo.DeliveryNodeEdiPackageRelation LEFT OUTER JOIN
                      dbo.EdiAsnPackage ON dbo.DeliveryNodeEdiPackageRelation.ediAsnPackageId = dbo.EdiAsnPackage.id LEFT OUTER JOIN
                      dbo.Part ON dbo.EdiAsnPackage.partId = dbo.Part.id

go

