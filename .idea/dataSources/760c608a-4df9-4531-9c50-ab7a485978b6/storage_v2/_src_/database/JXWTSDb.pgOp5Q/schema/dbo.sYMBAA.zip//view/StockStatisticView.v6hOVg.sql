
CREATE VIEW [dbo].[StockStatisticView]
AS
SELECT     dbo.Stock.id, dbo.Stock.whouseId, dbo.Stock.packageNr, dbo.Stock.qty, dbo.Stock.fifo, dbo.Stock.partId, dbo.Stock.orderNr, dbo.Stock.supplierId, dbo.Stock.creator, dbo.Stock.createdAt, 
                      dbo.Stock.updatedAt, dbo.Stock.packageType, dbo.EdiAsnPackage.ediAsnTransportId, dbo.EdiAsnPackage.ediDeliveryNodeId, dbo.EdiAsnPackage.internalid, dbo.EdiAsnPackage.parentid, 
                      dbo.EdiAsnPackage.quantityperpack, dbo.EdiAsnPackage.tara, dbo.EdiAsnPackage.itemnopackcustomer, dbo.EdiAsnPackage.itemnopacksupplier, dbo.EdiAsnPackage.ownership, 
                      dbo.EdiAsnPackage.recycling, dbo.EdiAsnPackage.batchno, dbo.EdiAsnPackage.klt, dbo.EdiAsnPackage.printflag, dbo.EdiAsnPackage.packagetype AS Expr1, dbo.EdiAsnPackage.delnotepositionid, 
                      dbo.EdiAsnPackage.quantitypack, dbo.EdiAsnPackage.labelnofrom, dbo.EdiAsnPackage.stacking, dbo.EdiAsnPackage.partId AS Expr2, dbo.EdiAsnPackage.orderno, 
                      dbo.EdiAsnPackage.supplierId AS Expr3, dbo.EdiAsnPackage.milkDate, dbo.EdiAsnPackage.parentPackageId, dbo.EdiAsnPackage.parentPathIds, dbo.EdiAsnPackage.state, 
                      dbo.EdiAsnPackage.currentWhouseId, dbo.EdiAsnPackage.currentDockPointId, dbo.EdiAsnPackage.currentUserId, dbo.EdiAsnPackage.currentCarId, dbo.EdiAsnPackage.currentCarTrailerId, 
                      dbo.EdiAsnPackage.isChecked, dbo.EdiAsnPackage.checkedAt, dbo.EdiAsnPackage.checkUserId, dbo.EdiAsnPackage.checkCarId, dbo.EdiAsnPackage.checkCarTrailerId, 
                      dbo.EdiAsnPackage.lastDeliveryPackageRelationId, dbo.EdiAsnPackage.sentAt, dbo.EdiAsnPackage.receivedAt, dbo.EdiAsnPackage.dataSourceType, dbo.EdiAsnPackage.ediAsnPositionId, 
                      dbo.EdiAsnPackage.createdAt AS Expr4, dbo.EdiAsnPackage.updatedAt AS Expr5, dbo.EdiAsnPackage.dockPointId, dbo.EdiAsnPackage.delivDate
FROM         dbo.Stock LEFT OUTER JOIN
                      dbo.EdiAsnPackage ON dbo.Stock.packageNr = dbo.EdiAsnPackage.nr

go

