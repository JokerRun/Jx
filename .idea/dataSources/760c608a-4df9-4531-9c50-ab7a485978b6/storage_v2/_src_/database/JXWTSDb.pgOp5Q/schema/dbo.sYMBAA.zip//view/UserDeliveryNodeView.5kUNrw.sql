
CREATE VIEW [dbo].[UserDeliveryNodeView]
AS
SELECT     dbo.DeliveryNode.id, NULL AS carId, NULL AS userId, NULL AS carTrailerId, dbo.DeliveryNode.state, dbo.DeliveryNode.createdAt, dbo.DeliveryNode.updatedAt, dbo.DeliveryNode.isSent, 
                      dbo.DeliveryNode.sentAt, dbo.DeliveryNode.isReceived, dbo.DeliveryNode.receivedAt, dbo.DeliveryNode.isPickOver, dbo.DeliveryNode.pickOverAt, 
                      dbo.DeliveryNode.sourceWhouseId AS deliveryNodeSourceWhouseId, dbo.DeliveryNode.id AS deliveryNodeId, dbo.DeliveryNode.nr AS deliveryNodeNr, 
                      dbo.DeliveryNode.destinationWhouseId AS deliveryNodeDestinationWhouseId, dbo.DeliveryNode.currentWhouseId AS deliveryNodeCurrentWhouseId, 
                      dbo.DeliveryNode.state AS deliveryNodeState, dbo.DeliveryNode.createdAt AS deliveryNodeCreatedAt, dbo.DeliveryNode.updatedAt AS deliveryNodeUpdatedAt, 
                      dbo.DeliveryNode.createUserId AS deliveryNodeCreateUserId, dbo.DeliveryNode.isCarTroopDelivery AS deliveryNodeIsCarTroopDelivery, 
                      dbo.DeliveryNode.shouldSentArrivalDateTime AS deliveryNodeShouldSentArrivalDateTime, dbo.DeliveryNode.carTroopId AS deliveryNodeCarTroopId, 
                      dbo.DeliveryNode.goToPickDateTime AS deliveryNodeGoToPickDateTime, dbo.DeliveryNode.deliveryMode AS deliveryNodeDeliveryMode, dbo.DeliveryNode.isSent AS deliveryNodeIsSent, 
                      dbo.DeliveryNode.sentAt AS deliveryNodeSentAt, dbo.DeliveryNode.isReceived AS deliveryNodeIsReceived, dbo.DeliveryNode.receivedAt AS deliveryNodeReceivedAt, 
                      dbo.DeliveryNode.stowageCarRemark AS deliveryNodeStowageCarRemark, dbo.DeliveryNode.isPickOver AS deliveryNodeIsPickOver, dbo.DeliveryNode.pickOverAt AS deliveryNodePickOverAt, 
                      dbo.DeliveryNodeCar.state AS deliveryNodeCarState
FROM         dbo.DeliveryNode LEFT OUTER JOIN
                      dbo.DeliveryNodeCar ON dbo.DeliveryNode.id = dbo.DeliveryNodeCar.deliveryNodeId

go

