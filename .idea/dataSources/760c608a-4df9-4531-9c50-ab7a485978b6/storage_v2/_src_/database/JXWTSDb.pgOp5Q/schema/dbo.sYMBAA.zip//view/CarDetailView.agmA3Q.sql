
CREATE VIEW [dbo].[CarDetailView]
AS
SELECT     dbo.Car.id, dbo.Car.driverId, dbo.Car.Nr, dbo.Car.capacity, dbo.Car.description, dbo.Car.status, dbo.Car.carTypeId, dbo.Car.carTroopCode, dbo.Car.carAreaCode, dbo.CarArea.name AS CarAreaName, 
                      dbo.CarTroop.name AS CarTroopName, dbo.[User].name AS DriverName, dbo.CarType.nr AS carTypeNr, dbo.CarType.name AS carTypeName, dbo.Car.innerLength, dbo.Car.innerWidth, 
                      dbo.Car.innerHeight, dbo.CarTroop.id AS carTroopId
FROM         dbo.Car LEFT OUTER JOIN
                      dbo.CarType ON dbo.Car.carTypeId = dbo.CarType.id LEFT OUTER JOIN
                      dbo.CarArea ON dbo.Car.carAreaCode = dbo.CarArea.code LEFT OUTER JOIN
                      dbo.CarTroop ON dbo.Car.carTroopCode = dbo.CarTroop.code LEFT OUTER JOIN
                      dbo.[User] ON dbo.Car.driverId = dbo.[User].id

go

