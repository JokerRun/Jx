create PROCEDURE [dbo].[BackupDatabase](@FolderPath varchar(500)) 
as
DECLARE @FullPath varchar(1000) 
set @FullPath = @FolderPath+ 'BlueWTSDb_'+    REPLACE(CONVERT(varchar(100), GETDATE(), 112)+CONVERT(varchar(100), GETDATE(), 8),':','')+ '.bak'
backup database [BlueWTSDb] to disk=@FullPath WITH INIT 
return
go

