CREATE VIEW [dbo].[CarTrailerDetailView]
AS
SELECT     dbo.CarTrailer.id, dbo.CarTrailer.carAreaId, dbo.CarTrailer.nr, dbo.CarTrailer.length, dbo.CarTrailer.innerLength, dbo.CarTrailer.innerWidth, dbo.CarTrailer.innerHeight, dbo.CarTrailer.capacity, 
                      dbo.CarTrailer.carTroopId, dbo.CarTrailer.carTypeId, dbo.CarTroop.name AS CarTroopName, dbo.CarTroop.code AS CarTroopCode, dbo.CarArea.name AS CarAreaName, 
                      dbo.CarArea.code AS CarAreaCode, dbo.CarType.nr AS CarTypeNr, dbo.CarType.name AS CarTypeName, dbo.CarTrailer.status
FROM         dbo.CarTrailer LEFT OUTER JOIN
                      dbo.CarArea ON dbo.CarTrailer.carAreaId = dbo.CarArea.id LEFT OUTER JOIN
                      dbo.CarTroop ON dbo.CarTrailer.carTroopId = dbo.CarTroop.id LEFT OUTER JOIN
                      dbo.CarType ON dbo.CarTrailer.carTypeId = dbo.CarType.id
go

