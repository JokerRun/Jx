CREATE VIEW dbo.OrderListDetailView
AS
SELECT     dbo.DockPoint.name AS DockPointName, dbo.Part.Nr AS PartNr, dbo.Supplier.name AS SupplierName, dbo.Supplier.code AS SupplierCode, dbo.OrderList.id, dbo.OrderList.orderNr, 
                      dbo.OrderList.partId, dbo.OrderList.supplierId, dbo.OrderList.relDate, dbo.OrderList.delivDate, dbo.OrderList.qty, dbo.OrderList.sLoc, dbo.OrderList.orderType, dbo.OrderList.status, 
                      dbo.OrderList.scheduleQty, dbo.OrderList.deliveryQty, dbo.OrderList.plant, dbo.OrderList.hasChangeValue, dbo.OrderList.ChangedQty, dbo.DockPoint.code AS DockPointCode, 
                      dbo.OrderList.ChangedDockPointId, dbo.OrderList.islock, dbo.Supplier.description AS supplierDescription
FROM         dbo.OrderList LEFT OUTER JOIN
                      dbo.DockPoint ON dbo.OrderList.sLoc = dbo.DockPoint.id LEFT OUTER JOIN
                      dbo.Part ON dbo.OrderList.partId = dbo.Part.id LEFT OUTER JOIN
                      dbo.Supplier ON dbo.OrderList.supplierId = dbo.Supplier.id
go

